import tensorflow as tf
import cv2
import numpy as np
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense,Conv2D, Flatten, Dropout, MaxPooling2D
from tensorflow.keras.models import Model



# Define path
data_dir = r'C:\Users\SANJITH G\OneDrive\Desktop\python\CK+48'
data_dir = r'C:\Users\SANJITH G\OneDrive\Desktop\python\leapGestRecog'


# Load pre-trained emotion model (assuming it's already trained)
try:
    emotion_model = tf.keras.models.load_model('emotion_recognition_model.keras')
    print("Emotion model loaded successfully.")
except Exception as e:
    print(f"Error loading emotion model: {e}")

# Create action recognition model
base_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
x = GlobalAveragePooling2D()(base_model.output)
x = Dense(1024, activation='relu')(x)
action_output = Dense(10, activation='softmax')(x)  # Adjust number of classes as needed
action_model = Model(inputs=base_model.input, outputs=action_output)

# Compile action model
action_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
print("Action model compiled successfully.")

# Emotion labels
emotion_labels = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']

# Action labels (example, adjust based on your dataset)
action_labels = ['Punch', 'Kick', 'Wave', 'Clap', 'Jump', 'Run', 'Walk', 'Sit', 'Stand', 'Other']

def preprocess_for_emotion(img):
    img = cv2.resize(img, (48, 48))
    img = img / 255.0
    img = np.expand_dims(img, axis=0)
    img = np.expand_dims(img, axis=-1)
    return img

def preprocess_for_action(img):
    img = cv2.resize(img, (224, 224))
    img = tf.keras.applications.mobilenet_v2.preprocess_input(img)
    img = np.expand_dims(img, axis=0)
    return img

def main():
    cap = cv2.VideoCapture(0)
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

        # Predict action for the entire frame
        action_input = preprocess_for_action(frame)
        action_prediction = action_model.predict(action_input)
        action_index = np.argmax(action_prediction)
        action = action_labels[action_index]
        print(f"Predicted action: {action}")

        for (x, y, w, h) in faces:
            roi_gray = gray[y:y + h, x:x + w]
            face_input = preprocess_for_emotion(roi_gray)
            emotion_prediction = emotion_model.predict(face_input)
            emotion_index = np.argmax(emotion_prediction)
            emotion = emotion_labels[emotion_index]
            print(f"Predicted emotion: {emotion}")

            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(frame, f"Emotion: {emotion}", (x, y - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
        
        cv2.putText(frame, f"Action: {action}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
        cv2.imshow('Emotion and Action Recognition', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
